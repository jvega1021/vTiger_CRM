<?php  
	class  HelloWorld  {}
?>

